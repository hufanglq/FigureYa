# 部署指南 - 如何在线上访问Nomogram App

## 🌐 免费在线部署选项

### 1. GitHub Pages（推荐）
1. **将代码推送到GitHub**：
   ```bash
   git init
   git add .
   git commit -m "Initial nomogram app"
   git branch -M main
   git remote add origin https://github.com/yourusername/nomogram-app.git
   git push -u origin main
   ```

2. **启用GitHub Pages**：
   - 在GitHub仓库中，点击 Settings
   - 滚动到 Pages 部分
   - 选择 "Deploy from a branch"
   - 选择 "main" 分支和 "/ (root)" 文件夹
   - 点击 Save

3. **访问地址**：`https://yourusername.github.io/nomogram-app`

### 2. Netlify（最简单）
1. **访问**：https://netlify.com
2. **拖拽nomogram-app文件夹到网页上**
3. **获得随机URL**：https://random-name-123456.netlify.app

### 3. Vercel（开发者友好）
1. **访问**：https://vercel.com
2. **连接GitHub仓库**
3. **自动部署**

### 4. Firebase Hosting
1. **安装Firebase CLI**：
   ```bash
   npm install -g firebase-tools
   ```

2. **初始化项目**：
   ```bash
   firebase init hosting
   ```

3. **部署**：
   ```bash
   firebase deploy
   ```

## 📱 PWA安装到手机

### iOS（iPhone/iPad）
1. 在Safari中打开应用URL
2. 点击底部的"分享"按钮（📤）
3. 选择"添加到主屏幕"
4. 点击"添加"

### Android
1. 在Chrome中打开应用URL
2. 点击浏览器菜单（⋮）
3. 选择"添加到主屏幕"或"安装应用"
4. 点击"添加"

## 🔧 移动端优化建议

1. **响应式测试**：确保在不同手机尺寸上都能正常显示
2. **触摸优化**：按钮和输入框要足够大（至少44px）
3. **性能优化**：压缩图片，减少JavaScript文件大小
4. **离线功能**：Service Worker确保PWA功能正常

## 📊 临床测试建议

1. **易用性测试**：让医生试用界面
2. **准确性验证**：对比R版本的计算结果
3. **加载速度测试**：确保移动网络下快速加载
4. **跨平台测试**：iOS和Android都要测试

## 🚀 立即体验选项

如果不想部署，可以：

### 本地网络访问
```bash
# 1. 找到您的IP地址
ifconfig | grep "inet "

# 2. 在手机浏览器访问
http://[您的IP地址]:8000
```

### 使用ngrok（推荐给开发者）
```bash
# 1. 安装ngrok
brew install ngrok

# 2. 运行
ngrok http 8000

# 3. 复制显示的URL在手机浏览器访问
```

选择最适合您的方法！推荐使用Netlify，只需拖拽文件夹即可获得在线访问链接。